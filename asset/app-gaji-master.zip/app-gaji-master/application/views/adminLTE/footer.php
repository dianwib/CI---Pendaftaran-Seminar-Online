  <footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>Version</b> 0.1.0
      </div>
      <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="http://mascode.id">mascode</a>.</strong> All rights
      reserved.
    </div>
    <!-- /.container -->
  </footer>
