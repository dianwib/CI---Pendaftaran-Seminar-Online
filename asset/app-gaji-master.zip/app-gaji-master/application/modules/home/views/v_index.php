      <!-- Main content -->
      <section class="content" style="margin:7% 0 13% 0">
        <div class="error-page" style="text-align:center;">
          <div class="col-md-12" style="text-align:center; margin-bottom:50px;">
            <img src="<?php echo base_url(); ?>assets/dist/img/logo_pdf.png" style="max-width:100%;" alt="logo" />
          </div>
          <h3><i class="fa fa-money text-yellow"></i> Selamat Datang di Aplikasi SI-Gaji</h3>
          <br>
          <p>
            SI - Gaji (sistem informasi gaji) adalah aplikasi yang membantu HRD untuk dalam memberikan gaji plus upah lembur untuk pegawai di perusahan.
          </p>
          <hr style="border-top: 1px solid #d0d0d0;">
          <button type="button" onClick="location.href=('<?php echo site_url("Timbang"); ?>')" class="btn btn-default" style="margin-bottom:8px;">Lihat Gaji</button>
          <button type="button" onClick="location.href=('<?php echo site_url("Timbang/add"); ?>')" class="btn btn-primary" style="margin-bottom:8px;">Ambil Gaji</button>
          <!-- /.error-content -->
        </div>
      </section>
      <!-- /.content -->
