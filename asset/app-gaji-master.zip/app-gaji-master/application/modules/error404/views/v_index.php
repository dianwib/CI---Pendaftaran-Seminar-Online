		<!-- Main content -->
		<section class="content" style="margin:13% 0 13% 0">
			<div class="error-page">
				<h2 class="headline text-yellow" style="margin-top:0px;"> 404</h2>
				<div class="error-content">
					<h3><i class="fa fa-warning text-yellow"></i> Oops! Halaman tidak ditemukan.</h3>

					<p>
						Halaman yang anda tuju tidak ditemukan.
						silahkan kembali ke halaman <a href="<?php echo site_url('Home'); ?>">Home</a> atau klik tombol di bawah ini.
					</p>

					<button onClick="location.href=('<?php echo site_url("Home"); ?>')" type="button" class="btn btn-primary" style="margin-bottom:8px;">Kembali ke Home</button>
				</div>
				<!-- /.error-content -->
			</div>
			<!-- /.error-page -->
		</section>
		<!-- /.content -->
