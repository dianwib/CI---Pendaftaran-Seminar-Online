# CI-Sekolah
Project web sekolah menggunakan CI, masih jauh dari kata sempurna tapi secara functional sudah mencukupi.
