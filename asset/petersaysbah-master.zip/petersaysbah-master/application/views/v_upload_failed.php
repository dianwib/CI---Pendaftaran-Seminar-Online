<div class="row clearfix">
				<div class="col-md-8 column">
					
		<h3>Upload foto gagal</h3>	

<p><?php echo $error; ?></p>

		

</div>