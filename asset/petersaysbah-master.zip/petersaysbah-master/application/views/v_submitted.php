<div class="row clearfix">
				<div class="col-md-8 column">
					
		<h3>Terima kasih sudah mendaftar...</h3>	

<p>Selanjutnya anda dapat mengaktifkan akun anda dengan verifikasi. Silakan cek email anda untuk panduan verifikasi. Setelah verifikasi, anda dapat login untuk memantau ranking pada halaman Peringkat.</p>


		

</div>