<div class="col-md-4 column">
<div class="well">
<!-- <div class="alert alert-info">Standar nilai sementara : &nbsp&nbsp > <?php echo $standar_nilai; ?></div> -->

<img src="<?php echo $base_url; ?>/assets/img/hotline.png">
<h3>
<ul>
	<li>
	087 766 550 845
	</li>
	<li>
	087 866 746 737
	</li>
</ul>
</h3>
</div>
			</div>
</div>