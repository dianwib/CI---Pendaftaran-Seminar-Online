			<div class="row clearfix">
				<div class="col-md-12 column">
					<div class=""><hr>
										 <address> <strong>SMA Negeri 1 Dompu</strong>
										 <br>Jln. Soekarno - Hatta No.56 Dompu 84211 NTB<br>
										 <a target="_blank" href="http://sman1dompu.sch.id">http://sman1dompu.sch.id</a><br>
										 <!-- email : sman1_dompu@yahoo.co.id  / smanegeri1dompu@gmail.com</address> -->

					
					</div>
<hr><p class="text-center">
© SMAN 1 Dompu 2014 | <i>Toho Pahu Tupa Ro Lata</i>
</p>
			</div>
			</div>
		</div>
	</div>
</div>


</body>
</html>

