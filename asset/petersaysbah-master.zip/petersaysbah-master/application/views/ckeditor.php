<div class="row clearfix">
				<div class="col-md-8 column">
					
		<h3>Alur Pendaftaran</h3>	

 <textarea name="content" id="content" ><p>Example data</p></textarea>
    <?php echo display_ckeditor($ckeditor); ?>
		

</div>