<div class="row clearfix">
				<div class="col-md-8 column">
					
		<h3>Terima kasih sudah mendaftar...</h3>	

<p>Silakan login menggunakan akun yang anda daftarkan.</p>

		

</div>