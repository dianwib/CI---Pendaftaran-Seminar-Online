<div class="row clearfix">
				<div class="col-md-8 column">

		<h3><?php echo $title; ?></h3>	
		<p><?php echo $pesan; ?></p>				
		
		

</div>

