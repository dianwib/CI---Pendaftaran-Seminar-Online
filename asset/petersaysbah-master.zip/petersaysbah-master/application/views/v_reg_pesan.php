<div class="row clearfix">
				<div class="col-md-8 column">
					
		<h3><?php echo $title; ?></h3>	


		

</div>