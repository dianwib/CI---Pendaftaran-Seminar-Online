<div class="row clearfix">
				<div class="col-md-8 column">
					
		

<p>Lembar Registrasi Penerimaan Siswa Baru Daring - SMA Negeri 1 Dompu</p>

<p>Output di sini berbentuk berkas pdf, yang dapat langsung dibuka di peramban web atau diunduh, kemudian dicetak untuk dibawa serta ke saat penyerahan berkas di sekolah</p>

		<?php 


		?>

</div>