<div class="row clearfix">
				<div class="col-md-8 column">
					
		<h3>Terima kasih sudah mendaftar...</h3>	

<p>Silakan melakukan verifikasi email. Cek email anda dan ikuti petunjuknya. Jika anda tidak menemukan email dari kami, mungkin email tersangkut di kotak spam</p>

		

</div>