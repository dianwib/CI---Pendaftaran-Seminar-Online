<div class="row clearfix">
				<div class="col-md-8 column">
<div class="alert alert-info">

<?php echo $message; ?>

</di>
</di>