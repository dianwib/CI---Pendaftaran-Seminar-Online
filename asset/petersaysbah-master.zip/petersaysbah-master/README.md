petersaysbah
============

sistem informasi penerimaan siswa baru aka psb, dibikin di atas CodeIgniter dan Twitter Bootstrap. sistem ini dirancang untuk sekolah-sekolah yang belum terjangkau siap-ppdb milik 
Telkom. jika kota/kabupaten anda sudah ada desas-desus penggunaan siap-ppdb, anda sebaiknya mengabaikan petersaysbah.

##gimana gimana

import database di db/.

untuk masuk admin,
user : admin@admin.admin
pass : admin

jika user admin mau diganti, silakan ganti emailnya di tabel users, kolom email, baris id=1. kolom lain biarkan.

di applications/config/, atur konfigurasi untuk database.php dan email.php
jangan lupa sesuaikan path di htaccess dan pindahkan ke .htaccess.

##kok namanya demikian

karena saat pertama kali diminta bikin, saya dengarnya psd.

"sistem peter says denim? wth"
