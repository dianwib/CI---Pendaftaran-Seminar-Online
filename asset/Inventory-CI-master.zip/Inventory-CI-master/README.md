# Inventory-CI
Aplikasi Gudang berbasis Codeigniter 3
