<?php

	$smarty->display("index.tpl");


?>
