# CodeIgniter-3.1.4
CodeIgniter-3.1.4 Basic Set Up


** Download The Project.Keep in htdocs folder. Rename the project folder as _ci314_ **

Get a basic set up project of CodeIgniter-3.1.4 in
```
http://localhost/ci314/
```