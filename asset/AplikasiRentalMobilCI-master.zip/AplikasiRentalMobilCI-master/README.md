# Aplikasi Rental Mobil dengan Codeigniter 3
Aplikasi Rental Mobil dengan Codeigniter 3

Fitur:<br>
1. Login/Logout Admin<br>
2. Tambah Kendaraan<br>
3. Tambah Driver<br>
4. Tambah Merk Kendaraan<br>
5. Transaksi Peminjaman Kendaraan<br>
6. Laporan Export PDF


# Aplikasi Rental Mobil with Codeigniter 3
Applications Car Rental with CodeIgniter 3

Features:<br>
1. Login / Logout Admin<br>
2. Add Vehicle<br>
3. Add Driver<br>
4. Add Brand Vehicles<br>
5. Vehicle Loan Transaction<br>
6. Export Report PDF

any question? please send me email to poeji.exact@gmail.com (http://pujikartono.com)
