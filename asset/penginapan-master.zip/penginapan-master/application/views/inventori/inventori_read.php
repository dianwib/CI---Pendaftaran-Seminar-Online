
        <!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                <h3 class='box-title'>Inventori Read</h3>
        <table class="table table-bordered">
	    <tr><td>Nama Inventori</td><td><?php echo $nama_inventori; ?></td></tr>
	    <tr><td>Harga Inventori</td><td><?php echo $harga_inventori; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('inventori') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->