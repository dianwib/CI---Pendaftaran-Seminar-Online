
        <!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                <h3 class='box-title'>Kamar Read</h3>
        <table class="table table-bordered">
	    <tr><td>Nama Kamar</td><td><?php echo $nama_kamar; ?></td></tr>
	    <tr><td>No Kamar</td><td><?php echo $no_kamar; ?></td></tr>
	    <tr><td>Kapasitas</td><td><?php echo $kapasitas; ?></td></tr>
	    <tr><td>Status Kamar</td><td><?php echo $status_kamar; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('kamar') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->