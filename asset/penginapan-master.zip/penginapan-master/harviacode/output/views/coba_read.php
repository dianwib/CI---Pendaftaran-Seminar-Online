
        <!-- Main content -->
        <section class='content'>
          <div class='row'>
            <div class='col-xs-12'>
              <div class='box'>
                <div class='box-header'>
                <h3 class='box-title'>Coba Read</h3>
        <table class="table table-bordered">
	    <tr><td>Sdsdsd</td><td><?php echo $sdsdsd; ?></td></tr>
	    <tr><td></td><td><a href="<?php echo site_url('coba') ?>" class="btn btn-default">Cancel</a></td></tr>
	</table>
        </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div><!-- /.col -->
          </div><!-- /.row -->
        </section><!-- /.content -->