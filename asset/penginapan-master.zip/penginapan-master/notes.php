<?php echo unix_to_human(now()); ?>
