var cuenta= 1;
function blockMsg($msg){
	$.blockUI({
		message: $msg, 
		fadeIn: 700, 
		fadeOut: 700, 
		timeout: 2000, 
		showOverlay: false, 
		centerY: false, 
		css: { 
			width: '350px', 
			top: '10px', 
			left: '', 
			right: '10px', 
			border: 'none', 
			padding: '5px', 
			backgroundColor: '#000', 
			'-webkit-border-radius': '10px', 
			'-moz-border-radius': '10px', 
			opacity: .6, 
			color: '#fff' 
		} 
	});
	setTimeout($.unblockUI,2000);
}

function Activity($tour,$seats,$date,$time){
	this.tour= $tour;
	this.seats= $seats;
	this.date= $date;
	this.time= $time
}

$.fn.menuPos= function(){
	var w = location.pathname
	$('li',this).removeClass('active');
	switch(w){
		case '/lf-tickets/dashboard':

			$('li:first-child',this).addClass('active');
		break;
		case '/lf-tickets/tickets':
			$('li:nth-child(2)',this).addClass('active');
		break;
		default:
		
		break;
	}
}
$(document).ready(function(){
	$('#main-nav').menuPos();
	$('#login').submit(function(e){
		e.preventDefault();
		if($('#username').val() != '' && $('#password').val() != '' ){
			$.post($(this).attr('action'),$(this).serialize(),function(data){
				blockMsg(data.message);
				if (data.code == 200){
					location.replace('dashboard');
				}else{
					blockMsg(data.message);
				}
			});	
		}else{
			blockMsg('Introduce tus datos');
		}

	});
	$('#add_tour').click(function(e){
		e.preventDefault();
		if(cuenta < 5){
			var $copia= $('.tours_select:last-child').clone(false,false);
			var $removeVal= $('.tours_select:last-child select').val();

			$('option',$copia).each(function(i,elm){
				if($(elm).val() == $removeVal){
					$(elm).attr('disabled','disabled');
				}
			});
			$('.tours_container').append($copia);
			$('.shopping_date',$copia).datetimepicker({format:'DD/MM/YYYY'});
			$('.timepicker-input',$copia).timepicker();
			cuenta++
		}else{
			$.blockUI({message:'No se pueden agregar más actividades al ticket.'})
			setTimeout($.unblockUI,2000)
		}
	});
	$('.shopping_date').datetimepicker({format:'DD/MM/YYYY'});
	$('.timepicker-input').timepicker();

$('#booking_form').submit(function(e){
	e.preventDefault();
})
$('#booking_form').validate({
	rules:{
		client_name: 'required',
		client_email: {
			email: true,
			required: true,
		},
		client_phone:{
			number: true,
			minlength: 5
		},
		id_booking: 'required',
		pickup_location: 'required',
		shopping_date:'required',
		seats: 'required',
		booking_date: 'required',
		booking_hour: 'required'

	},
	submitHandler: function(form){	
		var $activities=[];
		var $formData={
			username: $('input[name= "client_name"]').val(),
			email:$('input[name= "client_email"]').val(),
			phone:$('input[name= "client_phone"]').val(),
			id_booking: $('input[name= "id_booking"]').val(),
			pickup_location: $('input[name= "pickup_location"]').val(),
			shopping_date: $('input[name= "shopping_date"]').val(),
			amount: $('input[name= "amount"]').val(),
			activities: $activities,
			bookings: (function(){
				$('.tours_select').each(function(i,elm){
					var tour= $('select',elm).val(),
					seats= $('input[name="seats"]',elm).val(),
					date= $('input[name="booking_date"]',elm).val(),
					time= $('input[name="booking_hour"]',elm).val();
					$activities.push(new Activity(tour,seats,date,time));
				})
			})()
		}
		console.log($formData)
		$.post('API/bookingRegistration',$formData,function(response){
			console.log(response)
			$('#ticket_success').modal();
			$('#ticket_success .modal-body').html(response.message);
		});
	}
});
$('#modal_close').click(function(){
	if($('#booking_form').length){
	$('#booking_form')[0].reset();
	$('.tours_select').not(':first-child').remove();
	cuenta=1;	
	}
})
});


