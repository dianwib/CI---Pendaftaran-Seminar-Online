var Ticket= (function(){
	var container= $('#tickets');
	var count= 0;
	var actualTicket;

	function _setActions(){
		
		$('.send_confirmation').click(function(e){
			
			var container = $(this).parents('.act_content'),
				cve = $('.cve',container).val(),
				transaction= $('.cve',container).data('transaction');

			actualTicket= container;
			if(cve == '' || cve == 'undefined'){
				$.blockUI({message:'Ingresa la clave de reservación'})
				setTimeout($.unblockUI, 2000)
			}else{
			_saveCVE(transaction,cve);	
			}
			
		})

		// $('.cve').change(function(e){
		// 	console.log('change')
		// 	var container= $(this).parents('.act_content');
		// 	if($(this).val() != ''){
		// 		$('.send_confirmation',container).removeClass('disabled');
		// 	}else{
		// 		$('.send_confirmation',container).addClass('disabled');
		// 	}
				
		// })
		$('.sendTicket').click(function(e){
			$.blockUI({message:'Procesando ticket...'})
			var container= $(e.target).parent().parent().parent().parent().parent();

			$.post('API/sendTicket',{ticket_id:container.data('ticket')},function(response){
				$.unblockUI();
				$response= JSON.parse(response);
				if($response.code==200){
					$('#success_mail').modal();	
					$('#success_mail .custom_message').html($response.message)	
					$('.panel-heading .label',container).removeClass('label-danger').addClass('label-success').html('CONFIRMADO');
					$('.boton',container).html('<a class="btn btn-default" href="'+$response.url+'" target="_blank">View ticket</a>')
				}else{
					$('#success_mail .custom_message').html($response.message)
					$('#success_mail').modal();	
				}
			})
		});
	}
	function _saveCVE(transaction,cve){
		$.blockUI({message:'Actualizando Ticket'})
		$.post('API/saveCVE',{'transaction':transaction,'cve':cve},function(response){
			var response= JSON.parse(response);
			
			if(response.code === 200){
				_updateTicket(cve);	
			}else{
				$('#success_mail .custom_message').html(response.message)
				$('#success_mail').modal();	
			}
			$.unblockUI();
		})
	}
	function _updateTicket(cve){
			// actualTicket.html('<p>'+cve+'<button class="btn btn-primary editTicket">Edit Confirmation</botton></p>');
			actualTicket.html('<h1><span class="muted small text-success"> Confirmation:</span>'+cve+'</h1>');
	}
	
	return{
		renderTicket:function(ticket){
			
			var formato= '<div class="ticket" data-ticket="'+ticket.ticket_id+'" >';
			formato+='<div class="col-md-12">'
			formato+=('<div class="panel panel-primary">');
			formato+=('<div class="panel-heading ">');
			(ticket.status== "CONFIRM")? formato+=('<span class="label label-success pull-right">CONFIRMADO</span>') : formato+=('<span class="label label-danger pull-right">PENDIENTE</span>');
			formato+=('<h3>'+ticket.order+'</h3>');
			formato+=('</div>');
			formato+=('<div class="panel-body">');
			formato+=('<p class="small muted">Client</p>');
			formato+=('<h3>'+ticket.client+'</h3>');
			formato+=('<p class="small muted">Pickup location</p>');
			formato+=('<h3>'+ticket.pickup+'</h3>');
			formato+=('<p class="muted">Booking activities:</p>');
			$.each(ticket.activities,function(i,activity){
				var fecha= new Date(activity.fecha);

				formato+=('<h3>'+activity.name+'</h3>');
				formato+=('<p><strong>Seats: </strong>'+activity.asientos);
				formato+=(' <strong>Date: </strong>'+fecha.getDay()+'/'+ fecha.getMonth()+'/'+fecha.getFullYear());
				formato+=(' <strong>Time: </strong>'+fecha.getHours()+':'+((fecha.getMinutes()< 10 )?'0'+fecha.getMinutes() : fecha.getMinutes())+'</p>');
				if(!activity.confirmation_key){
					formato+='<div class="act_content">'
					formato+='<div class="col-md-offset-2 col-md-6">';
					formato+=('<input class="form-control cve" type="text" data-transaction="'+activity.transaction+'" placeholder="Introduce la clave de confirmación" />');
					formato+='</div>';
					formato+='<div class="col-md-4">';
					formato+=('<button class="btn btn-primary send_confirmation">Guardar</botton>');
					formato+='</div>';
					formato+='</div>';

				}else{
					
					// formato+=('<p>'+activity.confirmation_key+'<button class="btn btn-primary editTicket">Edit Confirmation</botton></p>');
					formato+=('<h1><span class="muted small text-success"> Confirmation:</span>'+activity.confirmation_key+'</h1>');
					
				}
			})

			formato+='<div class="row">&nbsp;</div>'
			formato+='<div class="text-right boton">'
			formato+=(ticket.status == "CONFIRM") ? '<a class="btn btn-default" href="'+ticket.url+'" target="_blank">View ticket</a>'  : '<button class="btn btn-primary sendTicket">Generate & Send ticket</botton>'
			formato+=('</div>');
			formato+=('</div>');
			formato+=('</div>');
			formato+=('</div>');
			formato+='</div>'
			return container.append(formato);
			
		},
		ticketOptions: function(){
			_setActions();
			return this;
		}
	}
})();
$(document).ready(function(){
	
	$.post('API/getalltickets',{},function(response){
		var $tickets= JSON.parse(response);
		if($tickets.length > 0){
			$.each($tickets,function(i,ticket){
				Ticket.renderTicket(ticket);
			});
			// later add promise to add actions
			Ticket.ticketOptions();	
		}else{
			$('#tickets').append('<div class="text-center"><h2 class="muted  text-warning">No hay tickets por el momento...</h2><p>Deseas registrar alguna reservación para generar un ticket.</p><a class="btn btn-primary" href="dashboard">Ir a Bookings</a></div><div style="padding-top:100px;"></div>')
		}
		
		
		
	});
});