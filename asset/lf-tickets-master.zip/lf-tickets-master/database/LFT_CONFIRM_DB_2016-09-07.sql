# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.42)
# Database: LFT_CONFIRM_DB
# Generation Time: 2016-09-07 16:03:34 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table LFT_ACTIVITIES
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_ACTIVITIES`;

CREATE TABLE `LFT_ACTIVITIES` (
  `id_activity` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`id_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_ACTIVITIES` WRITE;
/*!40000 ALTER TABLE `LFT_ACTIVITIES` DISABLE KEYS */;

INSERT INTO `LFT_ACTIVITIES` (`id_activity`, `name`, `description`)
VALUES
	(1,'Dolphin Royal Swim in Cancun-Isla Mujeres Dol','If you are the kind of person willing to experience the best, Dolphin VIP lounge in Isla Mujeres is your option because it offers an exclusive view of the Caribbean Sea while relaxing on the infinity pool having a premium drink from a selected liquor collection. With air conditioning and shades to cover you from the sun but still letting you enjoy the nicest weather of this paradise. Everybody gets delighted by the international exquisite buffet (shrimp, ravioli & pasta, salmon, salads, etc).'),
	(2,'Dolphin Swim Adventure in Cancun Isla Mujeres',NULL),
	(3,'Local Fractal \"Mexico Lindo\"',NULL),
	(4,'Local Fractal Boca del Puma Tour',NULL),
	(5,'Local Fractal Ceremonia Maya',NULL),
	(6,'Local Fractal Chichen Itza Plus',NULL),
	(7,'Local Fractal Combo Puma',NULL),
	(8,'Local Fractal Experience Dolphin Royal Swim P',NULL),
	(9,'Local Fractal Experience Dolphin Swim Adventu',NULL),
	(10,'Local Fractal Experience Xplor',NULL),
	(11,'Local Fractal Isla Mujeres',NULL),
	(12,'Local Fractal Joya by Cirque du Soleil Champa',NULL),
	(13,'Local Fractal Joya by Cirque du Soleil Dinner',NULL),
	(14,'Local Fractal Joya by Cirque du Soleil Show H',NULL),
	(15,'Local Fractal Joya by Cirque du Soleil Show O',NULL),
	(16,'Local Fractal Joya by Cirque du Soleil Vip Di',NULL),
	(17,'Local Fractal Jungle Speed Boat',NULL),
	(18,'Local Fractal Rio Secreto Entrance & Transpor',NULL),
	(19,'Local Fractal Rio Secreto Entrance Only',NULL),
	(20,'Local Fractal Rio Secreto Plus & Transportati',NULL),
	(21,'Local Fractal Xcaret Plus',NULL),
	(22,'Local Fractal Xelha',NULL),
	(23,'Local Fractal Xichen Deluxe',NULL);

/*!40000 ALTER TABLE `LFT_ACTIVITIES` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_ADDONS
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_ADDONS`;

CREATE TABLE `LFT_ADDONS` (
  `id_addon` int(11) NOT NULL,
  `name` varchar(128) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`id_addon`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table LFT_BOOKINGS
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_BOOKINGS`;

CREATE TABLE `LFT_BOOKINGS` (
  `id_booking` int(11) NOT NULL AUTO_INCREMENT COMMENT '	',
  `confirmation` varchar(45) DEFAULT NULL,
  `seats` tinyint(16) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `pickup_loc` varchar(45) DEFAULT NULL,
  `LFT_TICKETS_id_ticket` int(11) NOT NULL,
  `LFT_TICKETS_LFT_CLIENTES_id_client` int(11) NOT NULL,
  `LFT_ACTIVITIES_id_activity` int(11) NOT NULL,
  `LFT_ADDONS_id_addon` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_booking`,`LFT_TICKETS_id_ticket`,`LFT_TICKETS_LFT_CLIENTES_id_client`,`LFT_ACTIVITIES_id_activity`),
  KEY `fk_LFT_BOOKINGS_LFT_TICKETS1_idx` (`LFT_TICKETS_id_ticket`,`LFT_TICKETS_LFT_CLIENTES_id_client`),
  KEY `fk_LFT_BOOKINGS_LFT_ACTIVITIES1_idx` (`LFT_ACTIVITIES_id_activity`),
  KEY `fk_LFT_BOOKINGS_LFT_ADDONS1_idx` (`LFT_ADDONS_id_addon`),
  CONSTRAINT `fk_LFT_BOOKINGS_LFT_ACTIVITIES1` FOREIGN KEY (`LFT_ACTIVITIES_id_activity`) REFERENCES `LFT_ACTIVITIES` (`id_activity`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_LFT_BOOKINGS_LFT_ADDONS1` FOREIGN KEY (`LFT_ADDONS_id_addon`) REFERENCES `LFT_ADDONS` (`id_addon`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_LFT_BOOKINGS_LFT_TICKETS1` FOREIGN KEY (`LFT_TICKETS_id_ticket`, `LFT_TICKETS_LFT_CLIENTES_id_client`) REFERENCES `LFT_TICKETS` (`id_ticket`, `LFT_CLIENTES_id_client`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table LFT_CLIENTES
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_CLIENTES`;

CREATE TABLE `LFT_CLIENTES` (
  `id_client` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_client`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table LFT_TICKETS
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_TICKETS`;

CREATE TABLE `LFT_TICKETS` (
  `id_ticket` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_number` varchar(45) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `LFT_CLIENTES_id_client` int(11) NOT NULL,
  PRIMARY KEY (`id_ticket`,`LFT_CLIENTES_id_client`),
  KEY `fk_LFT_TICKETS_LFT_CLIENTES_idx` (`LFT_CLIENTES_id_client`),
  CONSTRAINT `fk_LFT_TICKETS_LFT_CLIENTES` FOREIGN KEY (`LFT_CLIENTES_id_client`) REFERENCES `LFT_CLIENTES` (`id_client`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



# Dump of table LFT_USERS
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_USERS`;

CREATE TABLE `LFT_USERS` (
  `id_users` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `permissions` enum('ADMIN','AGENCY') NOT NULL DEFAULT 'AGENCY',
  `password` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id_users`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_USERS` WRITE;
/*!40000 ALTER TABLE `LFT_USERS` DISABLE KEYS */;

INSERT INTO `LFT_USERS` (`id_users`, `username`, `permissions`, `password`)
VALUES
	(1,'super','ADMIN','8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918'),
	(2,'fidelis','AGENCY','7c6057c5cadda2ed1ea13c3c925c88a959d7a64fb12069864bf27b4a3acd76b7');

/*!40000 ALTER TABLE `LFT_USERS` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
