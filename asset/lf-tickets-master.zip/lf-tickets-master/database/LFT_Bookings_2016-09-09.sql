# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.42)
# Database: LFT_Bookings
# Generation Time: 2016-09-09 05:07:16 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table LFT_Activities
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Activities`;

CREATE TABLE `LFT_Activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Activities` WRITE;
/*!40000 ALTER TABLE `LFT_Activities` DISABLE KEYS */;

INSERT INTO `LFT_Activities` (`id`, `name`, `description`)
VALUES
	(1,'Dolphin Royal Swim in Cancun-Isla Mujeres Dol','If you are the kind of person willing to experience the best, Dolphin VIP lounge in Isla Mujeres is your option because it offers an exclusive view of the Caribbean Sea while relaxing on the infinity pool having a premium drink from a selected liquor collection. With air conditioning and shades to cover you from the sun but still letting you enjoy the nicest weather of this paradise. Everybody gets delighted by the international exquisite buffet (shrimp, ravioli & pasta, salmon, salads, etc).'),
	(2,'Dolphin Swim Adventure in Cancun Isla Mujeres',NULL),
	(3,'Local Fractal \"Mexico Lindo\"',NULL),
	(4,'Local Fractal Boca del Puma Tour',NULL),
	(5,'Local Fractal Ceremonia Maya',NULL),
	(6,'Local Fractal Chichen Itza Plus',NULL),
	(7,'Local Fractal Combo Puma',NULL),
	(8,'Local Fractal Experience Dolphin Royal Swim P',NULL),
	(9,'Local Fractal Experience Dolphin Swim Adventu',NULL),
	(10,'Local Fractal Experience Xplor',NULL),
	(11,'Local Fractal Isla Mujeres',NULL),
	(12,'Local Fractal Joya by Cirque du Soleil Champa',NULL),
	(13,'Local Fractal Joya by Cirque du Soleil Dinner',NULL),
	(14,'Local Fractal Joya by Cirque du Soleil Show H',NULL),
	(15,'Local Fractal Joya by Cirque du Soleil Show O',NULL),
	(16,'Local Fractal Joya by Cirque du Soleil Vip Di',NULL),
	(17,'Local Fractal Jungle Speed Boat',NULL),
	(18,'Local Fractal Rio Secreto Entrance & Transpor',NULL),
	(19,'Local Fractal Rio Secreto Entrance Only',NULL),
	(20,'Local Fractal Rio Secreto Plus & Transportati',NULL),
	(21,'Local Fractal Xcaret Plus',NULL),
	(22,'Local Fractal Xelha',NULL),
	(23,'Local Fractal Xichen Deluxe',NULL);

/*!40000 ALTER TABLE `LFT_Activities` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_Addons
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Addons`;

CREATE TABLE `LFT_Addons` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Addons` WRITE;
/*!40000 ALTER TABLE `LFT_Addons` DISABLE KEYS */;

INSERT INTO `LFT_Addons` (`id`, `name`, `description`)
VALUES
	(0,NULL,NULL);

/*!40000 ALTER TABLE `LFT_Addons` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_Bookings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Bookings`;

CREATE TABLE `LFT_Bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '	',
  `order_id` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` varchar(45) DEFAULT NULL,
  `pickup_loc` varchar(45) DEFAULT NULL,
  `LFT_Clients_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`LFT_Clients_id`),
  KEY `fk_LFT_Bookings_LFT_Clients_idx` (`LFT_Clients_id`),
  CONSTRAINT `fk_LFT_Bookings_LFT_Clients` FOREIGN KEY (`LFT_Clients_id`) REFERENCES `LFT_Clients` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Bookings` WRITE;
/*!40000 ALTER TABLE `LFT_Bookings` DISABLE KEYS */;

INSERT INTO `LFT_Bookings` (`id`, `order_id`, `date`, `amount`, `pickup_loc`, `LFT_Clients_id`)
VALUES
	(14,'12','2016-09-19','1002','laguna',14),
	(15,'12','2016-09-19','1002','laguna',15),
	(16,'12','2016-09-19','1002','laguna',16),
	(17,'12','2016-09-19','1002','laguna',17),
	(18,'33230040','2016-09-21','1000','Laguna',18),
	(19,'33230040','2016-09-21','1000','Laguna',19),
	(20,'33230040','2016-09-21','1000','Laguna',20),
	(21,'332122','2016-09-12','234991','laguna',21),
	(22,'332122','2016-09-12','234991','laguna',22),
	(23,'332122','2016-09-12','234991','laguna',23),
	(24,'332122','2016-09-12','234991','laguna',24),
	(25,'332122','2016-09-12','234991','laguna',25),
	(26,'123123','2016-09-20','12312','asdasfffasf',26),
	(27,'123123','2016-09-20','12312','asdasfffasf',27),
	(28,'123123','2016-09-12','123','lasdhasd',28),
	(29,'123123','2016-09-12','123','lasdhasd',29),
	(30,'123123','2016-09-12','123','lasdhasd',30),
	(31,'123123','2016-09-12','123','lasdhasd',31),
	(32,'123123','2016-09-12','123','lasdhasd',32),
	(33,'123123','2016-09-12','123','lasdhasd',33),
	(34,'123123','2016-09-12','123','lasdhasd',34),
	(35,'123123','2016-09-12','123','lasdhasd',35),
	(36,'123123','2016-09-12','123','lasdhasd',36),
	(37,'121231','2016-09-21','123123','asdasd',37),
	(38,'121231','2016-09-21','123123','asdasd',38);

/*!40000 ALTER TABLE `LFT_Bookings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_bookings_R
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_bookings_R`;

CREATE TABLE `LFT_bookings_R` (
  `id` int(11) NOT NULL,
  `LFT_Bookings_id` int(11) NOT NULL,
  `LFT_Bookings_LFT_Clients_id` int(11) NOT NULL,
  `LFT_Activities_id` int(11) NOT NULL,
  `confirmation_key` varchar(128) DEFAULT NULL,
  `seats` tinyint(4) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `LFT_Addons_id` int(11) NOT NULL DEFAULT '0',
  `LFT_Tickets_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`LFT_Bookings_id`,`LFT_Bookings_LFT_Clients_id`,`LFT_Activities_id`,`LFT_Addons_id`,`LFT_Tickets_id`),
  KEY `fk_LFT_bookings_R_LFT_Bookings1_idx` (`LFT_Bookings_id`,`LFT_Bookings_LFT_Clients_id`),
  KEY `fk_LFT_bookings_R_LFT_Activities1_idx` (`LFT_Activities_id`),
  KEY `fk_LFT_bookings_R_LFT_Addons1_idx` (`LFT_Addons_id`),
  KEY `fk_LFT_bookings_R_LFT_Tickets1_idx` (`LFT_Tickets_id`),
  CONSTRAINT `fk_LFT_bookings_R_LFT_Activities1` FOREIGN KEY (`LFT_Activities_id`) REFERENCES `LFT_Activities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_LFT_bookings_R_LFT_Addons1` FOREIGN KEY (`LFT_Addons_id`) REFERENCES `LFT_Addons` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_LFT_bookings_R_LFT_Bookings1` FOREIGN KEY (`LFT_Bookings_id`, `LFT_Bookings_LFT_Clients_id`) REFERENCES `LFT_Bookings` (`id`, `LFT_Clients_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_LFT_bookings_R_LFT_Tickets1` FOREIGN KEY (`LFT_Tickets_id`) REFERENCES `LFT_Tickets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_bookings_R` WRITE;
/*!40000 ALTER TABLE `LFT_bookings_R` DISABLE KEYS */;

INSERT INTO `LFT_bookings_R` (`id`, `LFT_Bookings_id`, `LFT_Bookings_LFT_Clients_id`, `LFT_Activities_id`, `confirmation_key`, `seats`, `date`, `LFT_Addons_id`, `LFT_Tickets_id`)
VALUES
	(0,14,14,3,NULL,3,'0000-00-00 00:00:00',0,44),
	(0,14,14,4,NULL,3,'0000-00-00 00:00:00',0,44),
	(0,14,14,6,NULL,3,'0000-00-00 00:00:00',0,44),
	(0,15,15,3,NULL,3,'0000-00-00 00:00:00',0,45),
	(0,15,15,4,NULL,3,'0000-00-00 00:00:00',0,45),
	(0,15,15,6,NULL,3,'0000-00-00 00:00:00',0,45),
	(0,16,16,3,NULL,3,'2016-09-22 00:30:00',0,46),
	(0,16,16,4,NULL,3,'2016-09-21 00:30:00',0,46),
	(0,16,16,6,NULL,3,'2016-09-25 00:30:00',0,46),
	(0,17,17,3,NULL,3,'2016-09-22 00:30:00',0,47),
	(0,17,17,4,NULL,3,'2016-09-21 00:30:00',0,47),
	(0,17,17,6,NULL,3,'2016-09-25 00:30:00',0,47),
	(0,18,18,1,NULL,5,'2016-09-29 11:45:00',0,48),
	(0,18,18,2,NULL,5,'2016-09-14 11:45:00',0,48),
	(0,21,21,1,NULL,4,'2016-09-21 10:45:00',0,51),
	(0,21,21,4,NULL,4,'2016-09-21 10:45:00',0,51),
	(0,22,22,1,NULL,4,'2016-09-21 10:45:00',0,52),
	(0,22,22,4,NULL,4,'2016-09-21 10:45:00',0,52),
	(0,23,23,1,NULL,4,'2016-09-21 10:45:00',0,53),
	(0,23,23,4,NULL,4,'2016-09-21 10:45:00',0,53),
	(0,24,24,1,NULL,4,'2016-09-21 10:45:00',0,54),
	(0,24,24,4,NULL,4,'2016-09-21 10:45:00',0,54),
	(0,25,25,1,NULL,4,'2016-09-21 10:45:00',0,55),
	(0,25,25,4,NULL,4,'2016-09-21 10:45:00',0,55),
	(0,26,26,1,NULL,2,'2016-09-26 10:45:00',0,56),
	(0,26,26,3,NULL,2,'2016-09-25 10:45:00',0,56),
	(0,27,27,1,NULL,2,'2016-09-26 10:45:00',0,57),
	(0,27,27,3,NULL,2,'2016-09-25 10:45:00',0,57),
	(0,28,28,5,NULL,2,'2016-09-29 11:00:00',0,58),
	(0,29,29,5,NULL,2,'2016-09-29 11:00:00',0,59),
	(0,30,30,5,NULL,2,'2016-09-29 11:00:00',0,60),
	(0,31,31,5,NULL,2,'2016-09-29 11:00:00',0,61),
	(0,32,32,5,NULL,2,'2016-09-29 11:00:00',0,62),
	(0,33,33,5,NULL,2,'2016-09-29 11:00:00',0,63),
	(0,34,34,1,NULL,2,'2016-09-29 11:00:00',0,64),
	(0,34,34,5,NULL,2,'2016-09-29 11:00:00',0,64),
	(0,35,35,1,NULL,2,'2016-09-29 11:00:00',0,65),
	(0,35,35,5,NULL,2,'2016-09-29 11:00:00',0,65),
	(0,36,36,1,NULL,2,'2016-09-29 11:00:00',0,66),
	(0,36,36,5,NULL,2,'2016-09-29 11:00:00',0,66),
	(0,37,37,3,NULL,1,'2016-09-19 11:15:00',0,67),
	(0,38,38,3,NULL,1,'2016-09-19 11:15:00',0,68);

/*!40000 ALTER TABLE `LFT_bookings_R` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_Clients
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Clients`;

CREATE TABLE `LFT_Clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Clients` WRITE;
/*!40000 ALTER TABLE `LFT_Clients` DISABLE KEYS */;

INSERT INTO `LFT_Clients` (`id`, `name`, `email`, `phone`)
VALUES
	(14,'PAco','paco@localfractal.com','PAco'),
	(15,'PAco','paco@localfractal.com','PAco'),
	(16,'PAco','paco@localfractal.com','PAco'),
	(17,'PAco','paco@localfractal.com','PAco'),
	(18,'test','test@test.com','test'),
	(19,'test','test@test.com','test'),
	(20,'test','test@test.com','test'),
	(21,'test','test@testw.com','test'),
	(22,'test','test@testw.com','test'),
	(23,'test','test@testw.com','test'),
	(24,'test','test@testw.com','test'),
	(25,'test','test@testw.com','test'),
	(26,'papsdoo','pasdpasd@asdjasd.com','papsdoo'),
	(27,'papsdoo','pasdpasd@asdjasd.com','papsdoo'),
	(28,'asda','asdasd@asdj.com','asda'),
	(29,'asda','asdasd@asdj.com','asda'),
	(30,'asda','asdasd@asdj.com','asda'),
	(31,'asda','asdasd@asdj.com','asda'),
	(32,'asda','asdasd@asdj.com','asda'),
	(33,'asda','asdasd@asdj.com','asda'),
	(34,'asda','asdasd@asdj.com','asda'),
	(35,'asda','asdasd@asdj.com','asda'),
	(36,'asda','asdasd@asdj.com','asda'),
	(37,'PAco','asdasdj@asdasd','PAco'),
	(38,'PAco','asdasdj@asdasd','PAco'),
	(39,'','','');

/*!40000 ALTER TABLE `LFT_Clients` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_Tickets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Tickets`;

CREATE TABLE `LFT_Tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('PENDING','CONFIRM','ERROR','IDDLE') DEFAULT NULL,
  `ticket_url` varchar(45) DEFAULT NULL,
  `ticket_qr` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Tickets` WRITE;
/*!40000 ALTER TABLE `LFT_Tickets` DISABLE KEYS */;

INSERT INTO `LFT_Tickets` (`id`, `date`, `status`, `ticket_url`, `ticket_qr`)
VALUES
	(44,'2016-09-09 02:09:49','PENDING',NULL,NULL),
	(45,'2016-09-09 02:09:36','PENDING',NULL,NULL),
	(46,'2016-09-09 02:09:23','PENDING',NULL,NULL),
	(47,'2016-09-09 03:09:26','PENDING',NULL,NULL),
	(48,'2016-09-09 05:09:36','PENDING',NULL,NULL),
	(49,'2016-09-09 05:09:29','PENDING',NULL,NULL),
	(50,'2016-09-09 05:09:46','PENDING',NULL,NULL),
	(51,'2016-09-09 05:09:53','PENDING',NULL,NULL),
	(52,'2016-09-09 05:09:12','PENDING',NULL,NULL),
	(53,'2016-09-09 05:09:37','PENDING',NULL,NULL),
	(54,'2016-09-09 05:09:47','PENDING',NULL,NULL),
	(55,'2016-09-09 05:09:03','PENDING',NULL,NULL),
	(56,'2016-09-09 05:09:06','PENDING',NULL,NULL),
	(57,'2016-09-09 05:09:39','PENDING',NULL,NULL),
	(58,'2016-09-09 05:09:22','PENDING',NULL,NULL),
	(59,'2016-09-09 05:09:48','PENDING',NULL,NULL),
	(60,'2016-09-09 05:09:02','PENDING',NULL,NULL),
	(61,'2016-09-09 05:09:37','PENDING',NULL,NULL),
	(62,'2016-09-09 05:09:45','PENDING',NULL,NULL),
	(63,'2016-09-09 05:09:48','PENDING',NULL,NULL),
	(64,'2016-09-09 05:09:07','PENDING',NULL,NULL),
	(65,'2016-09-09 05:09:36','PENDING',NULL,NULL),
	(66,'2016-09-09 06:09:07','PENDING',NULL,NULL),
	(67,'2016-09-09 06:09:21','PENDING',NULL,NULL),
	(68,'2016-09-09 06:09:00','PENDING',NULL,NULL);

/*!40000 ALTER TABLE `LFT_Tickets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_Users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Users`;

CREATE TABLE `LFT_Users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `role` enum('AGENCY','ADMIN') NOT NULL DEFAULT 'AGENCY',
  `password` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Users` WRITE;
/*!40000 ALTER TABLE `LFT_Users` DISABLE KEYS */;

INSERT INTO `LFT_Users` (`id`, `username`, `role`, `password`)
VALUES
	(1,'super','ADMIN','8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918'),
	(2,'fidelis','AGENCY','7c6057c5cadda2ed1ea13c3c925c88a959d7a64fb12069864bf27b4a3acd76b7');

/*!40000 ALTER TABLE `LFT_Users` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table new_view
# ------------------------------------------------------------

DROP VIEW IF EXISTS `new_view`;

CREATE TABLE `new_view` (
   `id` INT(11) NOT NULL DEFAULT '0',
   `date` TIMESTAMP NULL DEFAULT NULL,
   `status` ENUM('PENDING','CONFIRM','ERROR','IDDLE') NULL DEFAULT NULL,
   `ticket_url` VARCHAR(45) NULL DEFAULT NULL,
   `ticket_qr` VARCHAR(45) NULL DEFAULT NULL
) ENGINE=MyISAM;





# Replace placeholder table for new_view with correct view syntax
# ------------------------------------------------------------

DROP TABLE `new_view`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `new_view`
AS SELECT
   `lft_tickets`.`id` AS `id`,
   `lft_tickets`.`date` AS `date`,
   `lft_tickets`.`status` AS `status`,
   `lft_tickets`.`ticket_url` AS `ticket_url`,
   `lft_tickets`.`ticket_qr` AS `ticket_qr`
FROM `lft_tickets`;

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
