# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.5.42)
# Database: LFT_Bookings
# Generation Time: 2016-09-08 19:08:14 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table LFT_Activities
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Activities`;

CREATE TABLE `LFT_Activities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) DEFAULT NULL,
  `description` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Activities` WRITE;
/*!40000 ALTER TABLE `LFT_Activities` DISABLE KEYS */;

INSERT INTO `LFT_Activities` (`id`, `name`, `description`)
VALUES
	(1,'Dolphin Royal Swim in Cancun-Isla Mujeres Dol','If you are the kind of person willing to experience the best, Dolphin VIP lounge in Isla Mujeres is your option because it offers an exclusive view of the Caribbean Sea while relaxing on the infinity pool having a premium drink from a selected liquor collection. With air conditioning and shades to cover you from the sun but still letting you enjoy the nicest weather of this paradise. Everybody gets delighted by the international exquisite buffet (shrimp, ravioli & pasta, salmon, salads, etc).'),
	(2,'Dolphin Swim Adventure in Cancun Isla Mujeres',NULL),
	(3,'Local Fractal \"Mexico Lindo\"',NULL),
	(4,'Local Fractal Boca del Puma Tour',NULL),
	(5,'Local Fractal Ceremonia Maya',NULL),
	(6,'Local Fractal Chichen Itza Plus',NULL),
	(7,'Local Fractal Combo Puma',NULL),
	(8,'Local Fractal Experience Dolphin Royal Swim P',NULL),
	(9,'Local Fractal Experience Dolphin Swim Adventu',NULL),
	(10,'Local Fractal Experience Xplor',NULL),
	(11,'Local Fractal Isla Mujeres',NULL),
	(12,'Local Fractal Joya by Cirque du Soleil Champa',NULL),
	(13,'Local Fractal Joya by Cirque du Soleil Dinner',NULL),
	(14,'Local Fractal Joya by Cirque du Soleil Show H',NULL),
	(15,'Local Fractal Joya by Cirque du Soleil Show O',NULL),
	(16,'Local Fractal Joya by Cirque du Soleil Vip Di',NULL),
	(17,'Local Fractal Jungle Speed Boat',NULL),
	(18,'Local Fractal Rio Secreto Entrance & Transpor',NULL),
	(19,'Local Fractal Rio Secreto Entrance Only',NULL),
	(20,'Local Fractal Rio Secreto Plus & Transportati',NULL),
	(21,'Local Fractal Xcaret Plus',NULL),
	(22,'Local Fractal Xelha',NULL),
	(23,'Local Fractal Xichen Deluxe',NULL);

/*!40000 ALTER TABLE `LFT_Activities` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_Addons
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Addons`;

CREATE TABLE `LFT_Addons` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Addons` WRITE;
/*!40000 ALTER TABLE `LFT_Addons` DISABLE KEYS */;

INSERT INTO `LFT_Addons` (`id`, `name`, `description`)
VALUES
	(0,NULL,NULL);

/*!40000 ALTER TABLE `LFT_Addons` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_Bookings
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Bookings`;

CREATE TABLE `LFT_Bookings` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '	',
  `order_id` varchar(45) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `amount` varchar(45) DEFAULT NULL,
  `pickup_loc` varchar(45) DEFAULT NULL,
  `LFT_Clients_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`LFT_Clients_id`),
  KEY `fk_LFT_Bookings_LFT_Clients_idx` (`LFT_Clients_id`),
  CONSTRAINT `fk_LFT_Bookings_LFT_Clients` FOREIGN KEY (`LFT_Clients_id`) REFERENCES `LFT_Clients` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Bookings` WRITE;
/*!40000 ALTER TABLE `LFT_Bookings` DISABLE KEYS */;

INSERT INTO `LFT_Bookings` (`id`, `order_id`, `date`, `amount`, `pickup_loc`, `LFT_Clients_id`)
VALUES
	(1,'123123123123',NULL,NULL,NULL,1),
	(2,'123111231233','0000-00-00',NULL,'LAguna',2),
	(3,'123111231233','0000-00-00','1000','LAguna',2),
	(4,'123111231233','0000-00-00','1000','LAguna',2),
	(5,'123111231233','0000-00-00','1000','LAguna',2),
	(6,'123111231233','0000-00-00','1000','LAguna',2),
	(7,'123111231233','0000-00-00','1000','LAguna',2),
	(8,'123111231233','0000-00-00','1000','LAguna',2),
	(9,'123111231233','0000-00-00','1000','LAguna',2),
	(10,'123111231233','0000-00-00','1000','LAguna',2),
	(11,'123111231233','0000-00-00','1000','LAguna',2),
	(12,'123111231233','0000-00-00','1000','LAguna',2),
	(13,'123111231233','0000-00-00','1000','LAguna',2),
	(14,'123111231233','0000-00-00','1000','LAguna',2),
	(15,'123111231233','0000-00-00','1000','LAguna',2),
	(16,'123111231233','0000-00-00','1000','LAguna',2),
	(17,'123111231233','2016-09-20','1000','LAguna',2),
	(18,'123111231233','2016-09-20','1000','LAguna',2),
	(19,'123111231233','2016-09-20','1000','LAguna',2),
	(20,'123111231233','2016-09-20','1000','LAguna',2),
	(21,'123111231233','2016-09-20','1000','LAguna',2),
	(22,'34554443','2016-09-05','100','Laguna',1),
	(23,'34554443','2016-09-05','100','Laguna',1),
	(24,'34554443','2016-09-05','100','Laguna',1),
	(25,'34554443','2016-09-05','100','Laguna',1),
	(26,'34554443','2016-09-05','100','Laguna',1),
	(27,'34554443','2016-09-05','100','Laguna',1),
	(28,'34554443','2016-09-05','100','Laguna',1),
	(29,'34554443','2016-09-05','100','Laguna',1),
	(30,'34554443','2016-09-05','100','Laguna',1),
	(31,'34554443','2016-09-05','100','Laguna',1),
	(32,'34554443','2016-09-05','100','Laguna',1),
	(33,'34554443','2016-09-05','100','Laguna',1),
	(34,'34554443','2016-09-05','100','Laguna',1),
	(35,'34554443','2016-09-05','100','Laguna',1),
	(36,'34554443','2016-09-05','100','Laguna',1),
	(37,'34554443','2016-09-05','100','Laguna',1),
	(38,'34554443','2016-09-05','100','Laguna',1),
	(39,'34554443','2016-09-05','100','Laguna',1),
	(40,'34554443','2016-09-05','100','Laguna',40),
	(41,'34554443','2016-09-05','100','Laguna',41),
	(42,'34554443','2016-09-05','100','Laguna',42),
	(43,'34554443','2016-09-05','100','Laguna',43),
	(44,'34554443','2016-09-05','100','Laguna',44),
	(45,'34554443','2016-09-05','100','Laguna',45),
	(46,'34554443','2016-09-05','100','Laguna',46),
	(47,'34554443','2016-09-05','100','Laguna',47),
	(48,'34554443','2016-09-05','100','Laguna',48),
	(49,'34554443','2016-09-05','100','Laguna',49),
	(50,'34554443','2016-09-05','100','Laguna',50),
	(51,'34554443','2016-09-05','100','Laguna',51),
	(52,'33423','2016-09-24','10002','Laguna',52),
	(53,'33423','2016-09-24','10002','Laguna',53);

/*!40000 ALTER TABLE `LFT_Bookings` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_bookings_R
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_bookings_R`;

CREATE TABLE `LFT_bookings_R` (
  `id` int(11) NOT NULL,
  `LFT_Bookings_id` int(11) NOT NULL,
  `LFT_Bookings_LFT_Clients_id` int(11) NOT NULL,
  `LFT_Activities_id` int(11) NOT NULL,
  `confirmation_key` varchar(128) DEFAULT NULL,
  `seats` tinyint(4) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `LFT_Addons_id` int(11) NOT NULL DEFAULT '0',
  `LFT_Tickets_id` int(11) NOT NULL,
  PRIMARY KEY (`id`,`LFT_Bookings_id`,`LFT_Bookings_LFT_Clients_id`,`LFT_Activities_id`,`LFT_Addons_id`,`LFT_Tickets_id`),
  KEY `fk_LFT_bookings_R_LFT_Bookings1_idx` (`LFT_Bookings_id`,`LFT_Bookings_LFT_Clients_id`),
  KEY `fk_LFT_bookings_R_LFT_Activities1_idx` (`LFT_Activities_id`),
  KEY `fk_LFT_bookings_R_LFT_Addons1_idx` (`LFT_Addons_id`),
  KEY `fk_LFT_bookings_R_LFT_Tickets1_idx` (`LFT_Tickets_id`),
  CONSTRAINT `fk_LFT_bookings_R_LFT_Activities1` FOREIGN KEY (`LFT_Activities_id`) REFERENCES `LFT_Activities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_LFT_bookings_R_LFT_Addons1` FOREIGN KEY (`LFT_Addons_id`) REFERENCES `LFT_Addons` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_LFT_bookings_R_LFT_Bookings1` FOREIGN KEY (`LFT_Bookings_id`, `LFT_Bookings_LFT_Clients_id`) REFERENCES `LFT_Bookings` (`id`, `LFT_Clients_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_LFT_bookings_R_LFT_Tickets1` FOREIGN KEY (`LFT_Tickets_id`) REFERENCES `LFT_Tickets` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_bookings_R` WRITE;
/*!40000 ALTER TABLE `LFT_bookings_R` DISABLE KEYS */;

INSERT INTO `LFT_bookings_R` (`id`, `LFT_Bookings_id`, `LFT_Bookings_LFT_Clients_id`, `LFT_Activities_id`, `confirmation_key`, `seats`, `date`, `LFT_Addons_id`, `LFT_Tickets_id`)
VALUES
	(0,42,42,3,NULL,2,NULL,0,19),
	(0,42,42,4,NULL,2,NULL,0,19),
	(0,42,42,11,NULL,2,NULL,0,19),
	(0,43,43,3,NULL,2,NULL,0,20),
	(0,43,43,4,NULL,2,NULL,0,20),
	(0,43,43,11,NULL,2,NULL,0,20),
	(0,44,44,3,NULL,2,NULL,0,21),
	(0,44,44,4,NULL,2,NULL,0,21),
	(0,44,44,11,NULL,2,NULL,0,21),
	(0,45,45,3,NULL,2,NULL,0,22),
	(0,45,45,4,NULL,2,NULL,0,22),
	(0,45,45,11,NULL,2,NULL,0,22),
	(0,46,46,3,NULL,2,NULL,0,23),
	(0,46,46,4,NULL,2,NULL,0,23),
	(0,46,46,11,NULL,2,NULL,0,23),
	(0,47,47,3,NULL,2,NULL,0,24),
	(0,47,47,4,NULL,2,NULL,0,24),
	(0,47,47,11,NULL,2,NULL,0,24),
	(0,48,48,3,NULL,2,NULL,0,25),
	(0,48,48,4,NULL,2,NULL,0,25),
	(0,48,48,11,NULL,2,NULL,0,25),
	(0,49,49,3,NULL,2,NULL,0,26),
	(0,49,49,4,NULL,2,NULL,0,26),
	(0,49,49,11,NULL,2,NULL,0,26),
	(0,50,50,3,NULL,2,NULL,0,27),
	(0,50,50,4,NULL,2,NULL,0,27),
	(0,50,50,11,NULL,2,NULL,0,27),
	(0,51,51,3,NULL,2,NULL,0,28),
	(0,51,51,4,NULL,2,NULL,0,28),
	(0,51,51,11,NULL,2,NULL,0,28),
	(0,52,52,3,NULL,3,NULL,0,29),
	(0,52,52,11,NULL,3,NULL,0,29),
	(0,53,53,3,NULL,3,NULL,0,30),
	(0,53,53,11,NULL,3,NULL,0,30);

/*!40000 ALTER TABLE `LFT_bookings_R` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_Clients
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Clients`;

CREATE TABLE `LFT_Clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Clients` WRITE;
/*!40000 ALTER TABLE `LFT_Clients` DISABLE KEYS */;

INSERT INTO `LFT_Clients` (`id`, `name`, `email`, `phone`)
VALUES
	(1,'Paco','test@test.com','Paco'),
	(2,'PAco','paco@gmail.com','PAco'),
	(3,'PAco','paco@gmail.com','PAco'),
	(4,'PAco','paco@gmail.com','PAco'),
	(5,'PAco','paco@gmail.com','PAco'),
	(6,'PAco','paco@gmail.com','PAco'),
	(7,'PAco','paco@gmail.com','PAco'),
	(8,'PAco','paco@gmail.com','PAco'),
	(9,'PAco','paco@gmail.com','PAco'),
	(10,'PAco','paco@gmail.com','PAco'),
	(11,'PAco','paco@gmail.com','PAco'),
	(12,'PAco','paco@gmail.com','PAco'),
	(13,'PAco','paco@gmail.com','PAco'),
	(14,'PAco','paco@gmail.com','PAco'),
	(15,'PAco','paco@gmail.com','PAco'),
	(16,'PAco','paco@gmail.com','PAco'),
	(17,'PAco','paco@gmail.com','PAco'),
	(18,'PAco','paco@gmail.com','PAco'),
	(19,'PAco','paco@gmail.com','PAco'),
	(20,'PAco','paco@gmail.com','PAco'),
	(21,'PAco','paco@gmail.com','PAco'),
	(22,'TEst','test@test.com','TEst'),
	(23,'TEst','test@test.com','TEst'),
	(24,'TEst','test@test.com','TEst'),
	(25,'TEst','test@test.com','TEst'),
	(26,'TEst','test@test.com','TEst'),
	(27,'TEst','test@test.com','TEst'),
	(28,'TEst','test@test.com','TEst'),
	(29,'TEst','test@test.com','TEst'),
	(30,'TEst','test@test.com','TEst'),
	(31,'TEst','test@test.com','TEst'),
	(32,'TEst','test@test.com','TEst'),
	(33,'TEst','test@test.com','TEst'),
	(34,'TEst','test@test.com','TEst'),
	(35,'TEst','test@test.com','TEst'),
	(36,'TEst','test@test.com','TEst'),
	(37,'TEst','test@test.com','TEst'),
	(38,'TEst','test@test.com','TEst'),
	(39,'TEst','test@test.com','TEst'),
	(40,'TEst','test@test.com','TEst'),
	(41,'TEst','test@test.com','TEst'),
	(42,'TEst','test@test.com','TEst'),
	(43,'TEst','test@test.com','TEst'),
	(44,'TEst','test@test.com','TEst'),
	(45,'TEst','test@test.com','TEst'),
	(46,'TEst','test@test.com','TEst'),
	(47,'TEst','test@test.com','TEst'),
	(48,'TEst','test@test.com','TEst'),
	(49,'TEst','test@test.com','TEst'),
	(50,'TEst','test@test.com','TEst'),
	(51,'TEst','test@test.com','TEst'),
	(52,'Tester','tester@test.com','Tester'),
	(53,'Tester','tester@test.com','Tester');

/*!40000 ALTER TABLE `LFT_Clients` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_Tickets
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Tickets`;

CREATE TABLE `LFT_Tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `status` enum('PENDING','CONFIRM','ERROR','IDDLE') DEFAULT NULL,
  `ticket_url` varchar(45) DEFAULT NULL,
  `ticket_qr` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Tickets` WRITE;
/*!40000 ALTER TABLE `LFT_Tickets` DISABLE KEYS */;

INSERT INTO `LFT_Tickets` (`id`, `date`, `status`, `ticket_url`, `ticket_qr`)
VALUES
	(1,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(2,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(3,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(4,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(5,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(6,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(7,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(8,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(9,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(10,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(11,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(12,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(13,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(14,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(15,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(16,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(17,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(18,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(19,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(20,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(21,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(22,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(23,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(24,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(25,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(26,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(27,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(28,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(29,'0000-00-00 00:00:00',NULL,NULL,NULL),
	(30,'0000-00-00 00:00:00',NULL,NULL,NULL);

/*!40000 ALTER TABLE `LFT_Tickets` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table LFT_Users
# ------------------------------------------------------------

DROP TABLE IF EXISTS `LFT_Users`;

CREATE TABLE `LFT_Users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `role` enum('AGENCY','ADMIN') NOT NULL DEFAULT 'AGENCY',
  `password` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `LFT_Users` WRITE;
/*!40000 ALTER TABLE `LFT_Users` DISABLE KEYS */;

INSERT INTO `LFT_Users` (`id`, `username`, `role`, `password`)
VALUES
	(1,'super','ADMIN','8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918'),
	(2,'fidelis','AGENCY','7c6057c5cadda2ed1ea13c3c925c88a959d7a64fb12069864bf27b4a3acd76b7');

/*!40000 ALTER TABLE `LFT_Users` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
