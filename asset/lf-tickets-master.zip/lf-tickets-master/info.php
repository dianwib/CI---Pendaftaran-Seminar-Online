<?php 
phpinfo();
 ?>
