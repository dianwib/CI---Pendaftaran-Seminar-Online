<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class API extends CI_Controller {

	public function __construct(){
		parent::__construct();
		$this->load->helper('date');
		$this->load->helper('file');
	}
	public function bookingRegistration(){

		$this->load->model('Client','client');
		$this->load->model('Booking','booking_mdl');
		$this->load->model('Ticket');
		// if(empty($this->input->post('username'))){
		// 	die("error datos vacios");
		// }
		$cliente= $this->input->post('email');
		$existe= $this->client->getClientID($cliente);
		$response= array();
		$fecha = DateTime::createFromFormat('d/m/Y', $this->input->post('shopping_date'));
		$clientData= array(
				'username'=> $this->input->post('username'),
				'email'=> $this->input->post('email'),
				'phone'=> $this->input->post('phone')
			);

		if(!empty($existe)){
			$savedClient= $existe;
		}else{
			$savedClient= $this->client->saveClient($clientData);
		}
		// $savedClient=(!empty($this->client->getClientID($this->input->post('email'))))? $this->client->getClientID($this->input->post('email')) : $this->client->saveClient($clientData);
		$bookingData= array(
			'booking_id'		=> $this->input->post('id_booking'),
			'pickup_location'	=> $this->input->post('pickup_location'),
			'shopping_date'		=> $fecha->format('Y-m-d'),
			'email'			=>$this->input->post('email'),
			'amount'		=> $this->input->post('amount'),
			'client_id'		=>$savedClient
			);
		$savedBooking= $this->booking_mdl->saveBooking($bookingData);
		$savedTicket= $this->Ticket->createTicket();
		
		$relatedData= array(
			'booking_id'=>$savedBooking,
			'client_id'=>$savedClient,
			'ticket_id'=>$savedTicket,
			'activities'=>$this->input->post('activities')
			);
		$savedRelated=$this->booking_mdl->saveRelated($relatedData);

		if($savedRelated > 0){
			$response['code']= 200;
			$response['message']= sprintf("<p>El ticket %s fue generado exitosamente.<br> Deseas agregar los datos de confirmación.</p>", $savedTicket);
		}
		echo json_encode($response);
	}
	public function getAllTickets(){
		$this->load->model('Ticket');
		$response= array();
		$tickets = $this->Ticket->getTickets();
		
		foreach ($tickets as $key => $value) {
			$activities= $this->Ticket->getActivitesbyID($value['ticket_id']);	
			$tickets[$key]['activities']=$activities;
		}	

		echo json_encode($tickets);
	}

	public function saveCVE(){
		$response= array();
		$this->load->model('Ticket');
		$update=$this->Ticket->saveCVE($this->input->post('transaction'),$this->input->post('cve'));

		if($update > 0){
			$response['code']=200;
			$response['message']="success";
		}else{
			$response['code']=400;
			$response['message']="error";
		}
		echo json_encode($response);
	}
	public function sendTicket(){
		$this->load->model('Ticket');
		$response= array();
		$ticketID= $this->input->post('ticket_id');
		$ticket= $this->Ticket->getTicketByID($ticketID);
		$ticket[0]['activities']= $this->Ticket->getActivitesbyID($ticketID);
		$can_send= false;

		 foreach ($ticket[0]['activities'] as $activity_key) {
		 	if(!empty($activity_key['confirmation_key'])){
				$can_send= true;
		 	}else{
		 		$can_send= false;
				break;
		 	}
		 }

		if($can_send){
			$pdf= $this->_createPDF($ticket[0]);
			$email= $this->Ticket->getClientEmail($ticketID);
			$mailing= $this->_sendEmail($pdf,$email->email);
			$status= $this->Ticket->changeStatus($ticketID,'CONFIRM');	

		if($status > 0){
			$response['code']=200;
			$response['message']="El ticket fue generado y enviado por correo exitosamente.";
			$response['url']= base_url().$pdf;
		} else{
			$response['code']=400;
			$response['message']="error";
		}

		}else{
			$response['code']=404;
			$response['message']="Hace falta introducir alguna clave de confirmación para generar el ticket";
		}

		echo json_encode($response);
	}
	protected function _sendEmail($pdf, $email){
		$this->load->library('email');
		$this->load->helper('path');
		$this->load->helper('file');
		$msg= sprintf('<h1>Thanks to be part of Local Fractal</h1><p>This mail confirm your shopping on localfracta.</p><p><a href="%s">This is your confirmation ticket</a></p>',base_url().$pdf);
		$archivo= set_realpath($pdf);
		$this->email->from('no-replay@ielow.me', 'no-replay');
		$this->email->to($email);
		$this->email->subject('Local Fractal, Booking confirmation');
		$this->email->message($msg);
		$this->email->attach($archivo);
 		$this->email->send();
	}
	protected function _createQR($string){
		
		$this->load->library('Ciqrcode');

		$url='ticket/qr/qr-'.$string.'.png';

		
		$params['data'] = $string;
		$params['level'] = 'H';
		$params['size'] = 10;
		$params['quality'] = TRUE;
		$params['savename'] = $url;
		$this->ciqrcode->generate($params);

		return $url;
	}
	
	protected function _createPDF($ticket){
		$this->load->library('fpdf181/FPDF');
		$datestring = '%d/%m/%Y  %h:%i';
		if (!file_exists('ticket/qr')) {
    		mkdir('ticket/qr', 0777, true);
		}

		$url=("ticket/".$ticket['order'].".pdf");
		$qrCode= $this->_createQR($ticket['order']);
		$pdf = new FPDI('P','cm','letter');
		$pdf->AddPage();
		$pdf->setSourceFile('./ticket/tpl.pdf');
		$tpl= $pdf->importPage(1);
		$pdf->useTemplate($tpl);
		$pdf->SetFont('Arial','B',18);
		$pdf->Text(8.5,7.65,$ticket['client']);
		$pdf->Image($qrCode,16.14,.7, 4.5, 4.5);
		$pdf->Cell(0,9,'',0,1);
		$pdf->Cell(0,1,$ticket['order'],0,1,'C');
		$pdf->Cell(0,1,$ticket['pickup'],0,1,'C');
		if(count($ticket['activities']) < 4):
			foreach ($ticket['activities'] as $activity) {
				// $fecha= mdate($datestring, strtotime($activity['fecha']));
				$fecha= nice_date($activity['fecha'], 'd-m-Y h:i');
			 	$pdf->Cell(0,1,$activity['name'],0,1,'C');
			 	$pdf->SetFont('Arial','',10);
			 	$pdf->Cell(0,0.3,$fecha,0,1,'C');
			 	$pdf->Cell(0,0.3,$activity['asientos'],0,1,'C');
			 	$pdf->SetFont('Arial','B',21);
			 	$pdf->Cell(0,2,$activity['confirmation_key'],0,1,'C');
			 	$pdf->Cell(0,1,'',0,1);
			 }
		 endif;
		$pdf->SetCompression(TRUE);
		$pdf->Close();
		$content= $pdf->Output('S',FALSE);
		write_file($url,$content);
		$this->Ticket->saveQR($ticket['ticket_id'],$qrCode);
		$this->Ticket->savePDF($ticket['ticket_id'],base_url().$url);

		return $url;
	}
}

/* End of file API.php */
/* Location: ./application/controllers/API.php */