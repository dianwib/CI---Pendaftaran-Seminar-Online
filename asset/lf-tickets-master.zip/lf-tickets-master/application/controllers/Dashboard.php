<?php 

defined('BASEPATH') OR exit('No direct script access allowed');
/**
* 
*/
class Dashboard extends CI_Controller
{
	
	function __construct()
	{
		# code...
		parent::__construct();
	}
	function index(){
		if($this->session->has_userdata('username')):
		$this->layout_params['title']="Dashboard :: Local Fractal Tickets";
		$this->layout_params['view']='dashboard';
		$this->layout_params['obj']=$this;
		$this->load->view('layout/main', $this->layout_params);
		else:
			redirect(base_url());
		endif;
	}	
	public function selectActivities(){
		$list='<select class="form-control" >';
		$this->load->model('API');
		$activities =$this->API->listActivities();
		foreach ($activities as $activity) {
			$list.='<option value="'.$activity->id.'">'.$activity->name.'</option>';
		}
		$list.='<select>';
		return $list;
	}
}