<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tickets extends CI_Controller {
public $layout_params= array();

	public function __construct(){
		 parent::__construct();

	}
	public function index()
	{
		if($this->session->has_userdata('username')):
		$this->layout_params['title']="Tickets :: Local Fractal Tickets";
		$this->layout_params['view']='tickets';
		$this->layout_params['obj']=$this;
		$this->layout_params['tickets']=true;
		$this->load->view('layout/main', $this->layout_params);
		else:
			redirect(base_url());
		endif;
	}
}

/* End of file tickets.php */
/* Location: ./application/controllers/tickets.php */