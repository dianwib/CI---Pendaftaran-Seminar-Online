<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Login extends CI_Controller {
	
	public $layout_params= array();

	public function __construct(){
		 parent::__construct();

	}
	public function index(){
		$response;
		$this->load->model('User_model','user');
		$username= $this->input->post('username');
		$pass= $this->input->post('password');
		$access=$this->user->login_user($username, $pass);
		if(isset($access)){
			if($this->input->post('remember') != null){
				// Case to remember user
				$this->session->set_userdata(array(
					'username'		=>	$access->username,
					'role'	=>	$access->role
					));
			}else{
				// Close session after close window
				$this->session->set_tempdata(array(
					'username'		=>	$access->username,
					'role'	=>	$access->role
					),900);
			}
			$response= json_encode(array('code'=>200,'message'=>'Welcome '.$access->username ));
		}else{
			$response= json_encode(array('code'=>500,'message'=>'Datos incorrectos' ));
		}
		header('Content-Type: application/json');
		echo $response;
	}

}

 ?>