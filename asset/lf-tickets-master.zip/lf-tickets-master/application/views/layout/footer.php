<footer id="footer">
	<div class="container">
	<div class="text-center">
			<div class="muted credit">© Local Fractal 2016.</div>
		</div>
	</div>
</footer>