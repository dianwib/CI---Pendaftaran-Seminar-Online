<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
<ul id="main-nav" class="nav navbar-nav">
	<li class="active">
		<a  href="<?php echo base_url('dashboard'); ?>">Bookings</a>
	</li>
	<li>
		<a href="<?php echo base_url('tickets'); ?>">Tickets</a>
	</li>
	<li>
		<a href="logout">Logout</a>
	</li>
</ul>
</div>