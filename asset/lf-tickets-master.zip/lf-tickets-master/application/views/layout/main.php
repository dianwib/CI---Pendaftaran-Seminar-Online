<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?php echo $title; ?></title>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="<?php echo base_url('assets/libs/datepicker/css/bootstrap-datetimepicker.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/libs/timepicker/css/bootstrap-timepicker.min.css'); ?>">
<?php isset($header) ? $this->load->view($header): $this->load->view('layout/header');; ?>

</head>
<body>

<div id="wrapper">
	<?php $this->load->view($view);?>
</div>
<?php isset($footer)? $this->load->view($footer) : $this->load->view('layout/footer'); ?>

<script src="<?php echo base_url('assets/libs/jquery/jquery.min.js'); ?>"></script>
<!-- Latest compiled and minified JavaScript -->
<script src="<?php echo base_url('assets/libs/bootstrap/js/bootstrap.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/libs/blockUI/jquery.blockUI.js'); ?>"></script>
<script src="<?php echo base_url('assets/libs/moment/moment.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/libs/datepicker/js/bootstrap-datetimepicker.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/libs/timepicker/js/bootstrap-timepicker.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/libs/jquery.validate/jquery.validate.min.js'); ?>"></script>

<?php if(isset($tickets)): ?>
	<script src="<?php echo base_url('assets/js/tickets.js'); ?>"></script>
<?php endif; ?>
<script src="<?php echo base_url('assets/js/main.js'); ?>"></script>

</body>
</html>