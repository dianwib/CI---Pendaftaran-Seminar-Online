<main>
	<nav class="navbar navbar-default" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="#">
				<img alt="Brand" src="<?php echo base_url('assets/img/logo-local.png'); ?>" widht="24" height="24">
				</a>
			</div>
			<?php 
			($this->session->userdata('role') == "ADMIN")?
				$this->load->view('layout/admin-menu'):$this->load->view('layout/agency-menu',$this)
			?>	
		</div>
	</nav>
	
	<aside>
		<div class="container">
			<h1>Tickets</h1>
			<div id="tickets">
				
			</div>
		</div>
	</aside>
</main>

<!-- Modal -->
<div class="modal fade" id="success_mail" tabindex="-1" role="dialog" aria-labelledby="titleModal">
	<div class="modal-dialog" role="document">
		<div class="modal-content modal-success">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="titleModal">Modal title</h4>
			</div>
			<div class="modal-body">
				<div class="custom_message">
				<p>El ticket fue generado y enviado por correo al cliente, junto con sus claves de reservación.</p>
				</div>
			</div>
			<div class="modal-footer">
				<button id="modal_close" type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>