<div class="container">
	<header>
		<div class="row">
					<div class="col-md-12">
						<div class="text-center">
						<img width="210" src="<?php echo base_url('assets/img/logo-fractal.png') ?>" alt="Local Fractal">
						</div>
					</div>
				</div>
	</header>
		<main>
			<div class="row">
				<div class="col-sm-6 col-sm-offset-3">
					<div class="panel panel-primary">
						<div class="panel-heading text-center">
							<h3>Login</h3>
						</div>
						<div class="panel-body">
							<form id="login" action="login" method="post">
								<div class="form-group">
									<label for="username">User name</label>
									<input id="username" class="form-control" type="text" name="username" placeholder="User Name" >
								</div>
								<div class="form-group">
									<label for="password">password name</label>
			
									<input id="password" class="form-control" type="password" name="password" placeholder="insert your password" >	
								</div>
								<div class="checkbox">
									<label> 
										<input name="remember" type="checkbox" unchecked>
										Remember me.
									</label>
			
								</div>
								<div class="text-right">
									<button type="submit" class="btn btn-default">Submit</button>
								</div>
							</form>
						</div>
						<div class="panel-footer">
							<p class="small"> Local Fractal Tickets Confirmation</p>	
						</div>
					</div>
				</div>
			</div>
		</main>
	</div>