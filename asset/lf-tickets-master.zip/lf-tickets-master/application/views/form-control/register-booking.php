<form action="#" id="booking_form">
<div class="row">
	<h2>Local Fractal Bookings</h2>
	<p class="small">Agregar nuevos bookings para genera ticket</p>
</div>
<div class="row">
	<div class="col-md-12">
		<h3>Agregar datos del cliente</h3>
	</div>
	
		<div class="col-md-6">
			<div class="form-group">
				<label>Nombre cliente</label>
				<input class="form-control" type="text" name="client_name" />
			</div>
			<div class="form-group">
				<label>Correo electrónico</label>
				<input class="form-control" type="text" name="client_email" />
			</div>
			<div class="form-group">
				<label>Teléfono</label>
				<input class="form-control" type="text" name="client_phone" />
			</div>
		</div>
		<div class="col-md-6">
			<div class="form-group">
				<label>ID Booking</label>
				<input class="form-control" type="text" name="id_booking" />
			</div>
			<div class="form-group">
				<label>Fecha de compra</label>
				<div class='shopping_date input-group date' >
					<input type='text' class="form-control" name="shopping_date" />
					<span class="input-group-addon">
						<span class="glyphicon glyphicon-calendar"></span>
					</span>
				</div>
			</div>
			<div class="form-group">
				<label>Pick up Location</label>
				<input class="form-control" type="text" name="pickup_location" />
			</div>

			<div class="form-group">
				<label>Monto Compra</label>
				
				<div class="input-group">
					<span class="input-group-addon">
						<span class="glyphicon glyphicon-usd"></span>
					</span>
					<input class="form-control" type="text" name="amount" />
					<span class="input-group-addon">
						<span>USD</span>
					</span>
				</div>
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-md-12">
			<h3>Agregar actividades al ticket</h3>
			<div class="text-right">
				<button id="add_tour" class="btn btn-default">Agregar otra actividad <i class="glyphicon glyphicon-plus-sign"></i></button>
			</div>
		</div>
	</div>
	<!-- Addons -->	
	<div class="tours_container ">
	<div class="tours_select row">
			<div class="col-md-3">
				<div class="form-group ">
					<label>Selected Tour</label>
					<?php echo $obj->selectActivities(); ?>
				</div>
			</div>

			<div class="col-md-3">
				<div class="form-group">
					<label>Numero de asientos</label>
					<input class="form-control" type="number" name="seats"  min="1"  value="1" />
				</div>
			</div>
			<div class="col-md-3">
				<div class="form-group">
					<label>Fecha de reservación</label>
					<div class='shopping_date input-group date' >
						<input type='text' class="form-control" name="booking_date" />
						<span class="input-group-addon">
							<span class="glyphicon glyphicon-calendar"></span>
						</span>
					</div>
				</div>
			</div>

			<div class="col-md-3">
				<div class="form-group">
				<label>Hora de reservación</label>
					<div class="input-group bootstrap-timepicker timepicker">
						<input  type="text" class="form-control input-small timepicker-input" name="booking_hour">
						<span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="row">

		<div class="text-right">
			<input class="btn btn-primary form-control" type="submit" value="Registrar">
		</div>
	</div>
</div>
</form>
<!-- Modal -->
<div class="modal fade" id="ticket_success" tabindex="-1" role="dialog" aria-labelledby="titleModal">
	<div class="modal-dialog" role="document">
		<div class="modal-content modal-success">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="titleModal">Modal title</h4>
			</div>
			<div class="modal-body">
				El ticket se agrego exitosamente.

			</div>
			<div class="modal-footer">
				<button id="modal_close" type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<a class="btn btn-primary" href="<?php echo base_url('tickets'); ?>">Ver Tickets</a>
			</div>
		</div>
	</div>
</div>
