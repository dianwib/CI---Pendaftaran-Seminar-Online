
<main>
	<nav class="navbar navbar-default" role="navigation">
		<div class="container-fluid">
			<div class="navbar-header">
				<a class="navbar-brand" href="#">
				<img alt="Brand" src="<?php echo base_url('assets/img/logo-local.png'); ?>" widht="24" height="24">
				</a>
			</div>
			<?php 
			($this->session->userdata('role') == "ADMIN")?
			$this->load->view('layout/admin-menu'):$this->load->view('layout/agency-menu',$this)
			?>	
		</div>
	</nav>
	
	<aside>
		<div class="container">
			<?php $this->load->view('form-control/register-booking',$this); ?>
		</div>
	</aside>
</main>