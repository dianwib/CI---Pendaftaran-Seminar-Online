<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Booking extends CI_Model {

	public function __construct(){

	}
	public function saveBooking($data){
		$this->load->model('Client');
		$request= array(
			'order_id'=> $data['booking_id'],
			'date'=>  $data['shopping_date'],
			'pickup_loc'=> $data['pickup_location'],
			'amount'=> $data['amount'],
			'LFT_Clients_id'=> (isset($data['client_id']))?$data['client_id']: $this->Client->getClientID($data['email'])
			);
		 $q= $this->db->insert('LFT_Bookings',$request);
		return $this->db->insert_id();
	}
	public function saveRelated($data){
		$request= array();
	foreach ( $data['activities'] as $arr => $activity) {

		$reservation_date=DateTime::createFromFormat('d/m/Y', $activity['date']);
		$reservation_time= DateTime::createFromFormat('h:i A', $activity['time']);
		$reservation= $reservation_date->format('Y-m-d').' '.$reservation_time->format('H:i:s');
		array_push($request,array(
				'LFT_Bookings_id' 				=>  $data['booking_id'],
				'LFT_Bookings_LFT_Clients_id'	=>	$data['client_id'],
				'LFT_Activities_id'				=>	$activity['tour'],
				'LFT_Addons_id'					=>	0,
				'LFT_Tickets_id'				=>	$data['ticket_id'],
				'seats'							=>	$activity['seats'],
				'date'							=>	$reservation
			));
	}

		$this->db->insert_batch('LFT_Bookings_R',$request);
		return $this->db->affected_rows();
	}

}

/* End of file modelName.php */
/* Location: ./application/models/modelName.php */