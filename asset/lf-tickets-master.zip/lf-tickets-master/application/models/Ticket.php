<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ticket extends CI_Model {

	public function __construct(){
		parent::__construct();
		$this->load->helper('date');
	}
	public function createTicket(){
	$actual= mdate('%Y-%m-%d %h:%m:%s');
		$ticketData = array(
			'date' => $actual,
			'status'=> 'PENDING'
			);
		$this->db->insert('LFT_Tickets',$ticketData);
		return $this->db->insert_id();
	}
	public function getTickets(){
		$this->db->order_by('ticket_id','DESC');
		$q = $this->db->get('LFT_tickets_view');

		return $q->result_array();
	}
	public function getTicketByID($id){
		
		$this->db->where('ticket_id',$id);
		$q = $this->db->get('LFT_tickets_view');
		return $q->result_array();
	}
	public function getActivitesbyID($id){
		
		$this->db->where('ticket_id',$id);
		$q=$this->db->get('activities_view');
		return $q->result_array();

	}
	public function saveCVE($transaction,$cve){
		$this->db->set('confirmation_key', $cve);
		$this->db->where('id',$transaction);
		$this->db->update('LFT_Bookings_R');

		return $this->db->affected_rows();
	}
	public function changeStatus($ticket,$newStr="PENDING"){
		$this->db->set('status', $newStr);
		$this->db->where('id',$ticket);
		$this->db->update('LFT_Tickets');
		return $this->db->affected_rows();
	}
	public function savePDF($ticket_id, $pdf){
		$this->db->set('ticket_url',$pdf);
		$this->db->where('id',$ticket_id);
		$this->db->update('LFT_Tickets');
		return $this->db->affected_rows();
	}
	public function saveQR($ticket_id, $qr){
		$this->db->set('ticket_qr',$qr);
		$this->db->where('id',$ticket_id);
		$this->db->update('LFT_Tickets');
		return $this->db->affected_rows();
	}

	public function getClientEmail($id){
		$this->db->select('LFT_Clients.email');
		$this->db->from('LFT_Bookings_R');
		$this->db->where('LFT_Tickets_id', $id);
		$this->db->join('LFT_Clients', 'LFT_Bookings_R.LFT_Bookings_LFT_Clients_id = LFT_Clients.id');
		$this->db->limit(1);
		$query = $this->db->get();
		return $query->row();
	}
}

/* End of file modelName.php */
/* Location: ./application/models/modelName.php */