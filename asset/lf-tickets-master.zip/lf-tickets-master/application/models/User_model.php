<?php 

/**
* 
*/
class User_model extends CI_Model
{
	
	function __construct()
	{
		# code...
	}
	public function login_user($username,$pass){
		$this->db->select();
		$this->db->from('LFT_Users');
		$this->db->where('username',$username);
		$this->db->where('password',hash('sha256', $pass));
		$query= $this->db->get();
		return $query->row();
	}
}