<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class API extends CI_Model {

	function __construct(){
		parent::__construct();
	}
	function index(){

	}
	public function listActivities(){
		$q= $this->db->get('LFT_Activities');
		return $q->result();
	}

}

/* End of file API.php */
/* Location: ./application/models/API.php */