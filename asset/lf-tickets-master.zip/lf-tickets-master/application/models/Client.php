<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client extends CI_Model {

	public function __construct(){
		parent::__construct();
	}
	public function saveClient($data){
		$request= array(
			'name'=>$data['username'],
			'email'=> $data['email'],
			'phone'=>$data['phone']
			);
		$q= $this->db->insert('LFT_Clients',$request);
		return $this->db->insert_id();
	}
	public function getClientID($email){
		$this->db->select();
		$this->db->from('LFT_Clients');
		$this->db->where('email',$email);
		$q= $this->db->get();
		
		$ID= $q->row();

		if(!empty($ID)){
			return $ID->id;	
		}else{
			return null;
		}
		
	}
	

}

/* End of file modelName.php */
/* Location: ./application/models/modelName.php */