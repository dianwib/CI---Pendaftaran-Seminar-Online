<?php 
## SMTP Config
// $config['protocol'] = 'smtp';
// $config['smtp_host'] = 'relay-hosting.secureserver.net';
// $config['smtp_port'] = 25;
// $config['smtp_user'] = 'ielow@ielow.me';
// $config['smtp_pass'] = '4m4r1ll0';

## Sendmail Config
$config['protocol'] = 'sendmail';
$config['mailpath']= '/usr/sbin/sendmail -t -i ';
$config['charset'] = 'ISO-8859-1';
$config['wordwrap'] = TRUE;
$config['mailtype'] = 'html';
// $config['crlf'] = '\r\n';
// $config['newline'] = '\r\n';


// $confing['smtp_timeout']= 5;
// $config['smtp_keepalive']=  TRUE;
// $config['smtp_crypto']= 'ssl';
// $protocol = 'mail';
// $mailpath = '/usr/sbin/sendmail';
// $charset   = 'iso-8859-1';
// $wordwrap = TRUE;